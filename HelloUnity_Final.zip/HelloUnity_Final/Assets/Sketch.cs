using UnityEngine;
using Pathfinding.Serialization.JsonFx;
using System.Collections;

public class Sketch : MonoBehaviour {

    public GameObject myPrefab;
    public string _WebsiteURL = "http://lab05slian.azurewebsites.net/tables/Mountain?zumo-api-version=2.0.0";

    void Start () {
        string jsonResponse = Request.GET(_WebsiteURL);

        if (string.IsNullOrEmpty(jsonResponse))
        {
            return;
        }

        Mountain[] MountainName = JsonReader.Deserialize<Mountain[]>(jsonResponse);


        int totalCubes = MountainName.Length;
        //int totalDistance = 10;
        int i = 0;
        foreach (Mountain Mountain in MountainName)
        {
            float perc = i / (float)totalCubes;
            i++;
            //float x = perc * totalDistance;
            //float y = 5.0f;
            //float z = 0.0f;
            int X = Mountain.X;
            int Y = Mountain.Y;
            int Z = Mountain.Z;
            int Size = Mountain.Size;
            float x = X;
            float y = Y;
            float z = Z;
                                    
            GameObject newCube = (GameObject)Instantiate(myPrefab, new Vector3( x, y, z), Quaternion.identity);
            //newCube.GetComponent<CubeScript>().SetSize((1.0f - perc) *2);
            newCube.GetComponent<CubeScript>().SetSize(Size);
            newCube.GetComponent<CubeScript>().rotateSpeed = perc;
            newCube.GetComponentInChildren<TextMesh>().text = Mountain.MountainName;
        }        
	}
	
	void Update () {
	
	}
}
