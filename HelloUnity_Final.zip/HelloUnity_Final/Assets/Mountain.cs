﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Make sure you get rid of the namespace that is automatically generated here.
class Mountain
{
    //List all the columns of your table here in the same format as below.
    public string MountainId { get; set; }
    public string MountainName { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Z { get; set; }
    public int Size { get; set; }
    public string Symbol { get; set; }
}
